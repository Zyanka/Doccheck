# Анализ документов ЦБ: Lessons Learned

## Проблема: Защищённый формат .ppdf

**Ситуация:** При анализе ZIP-архивов из `/home/datalab/nfs/test-MVP/test/` обнаружено:
- Файлы имеют расширение `.ppdf` вместо `.pdf`
- Это защищённый формат Сбера (Microsoft IIS-based "pfile")
- PyPDF2 и pymupdf не могут извлечь текст напрямую
- XLSX файлы в архивах также повреждены или в нестандартном OLE2-формате

**Диагностика:**
```bash
cd /home/datalab/nfs/test-MVP/test
unzip -l "Письмо №ЦА-26-исх_349 от 04.05.2026.zip"
# Показывает: Письмо.ppdf (450 KB) — не настоящий PDF
```

**Решение:** Отказ от анализа ZIP-архивов с `.ppdf` в пользу **папок с документами**:
- Документы ЦБ хранятся в папках вида `Письмо ЦА-662-исх_X от DD.MM.YYYY/`
- Внутри папок — обычные PDF и DOCX файлы
- Скрипт `analyze_cb_docs.py` сканирует папки и извлекает текст напрямую

---

## Успешный паттерн: Анализ папок вместо ZIP

**Скрипт:** `analyze_cb_docs.py`

**Команда:**
```bash
python3 analyze_cb_docs.py --input-dir цб --output cb_report_full.md
```

**Результат:**
- ✅ 75 папок проанализировано
- ✅ 180 документов извлечено (PDF + DOCX)
- ✅ LLM-анализ выполнен (GigaChat Qwen3.5-397b)
- ✅ Отчёт сохранён в `cb_report_full.md`

**Структура папок:**
```
цб/
├── Письмо ЦА-662-исх_1 от 14.01.2026/
│   ├── Письмо.pdf
│   └── Письмо (со штампами).pdf
├── Письмо ЦА-662-исх_10 от 02.02.2026/
│   ├── Письмо.pdf
│   ├── Письмо (со штампами).pdf
│   ├── Разбор кейса.docx
│   └── Документы по кейсам.docx
...
```

---

## Критические настройки LLM API

### Проблема: Timeout при анализе

**Симптом:**
```
[Ошибка LLM: HTTPConnectionPool(host='liveaccess', port=80): Read timed out. (read timeout=60)]
```

**Причина:** Анализ 10+ документов требует больше 60 секунд на один вызов API.

**Решение:** Увеличен timeout в `doccheck_batch.py`:
```python
# Было:
timeout=60

# Стало:
def _call_llm(self, prompt: str, max_tokens: int = 4000, timeout: int = 120) -> str:
    # ...
    response = requests.post(..., timeout=timeout)

# Для analyse_batch:
report = self._call_llm(prompt, max_tokens=8000, timeout=180)
```

**Рекомендация:** Для анализа >50 документов использовать timeout 120-180 секунд.

---

## Извлечённые риски (пример отчёта)

Из полного анализа 75 папок (Июнь 2025 — Февраль 2026):

### 2.1 Операционные риски
- **Использование недействующих нормативных документов** — письмо от 16.02.2026 ссылается на Положение № 4215-11, срок действия которого истёк 08.04.2025
- **Нарушение сроков по 161-ФЗ** — автоматизация запланирована только на II полугодие 2026

### 2.2 Недостатки процессов
- **Подтверждённые нарушения 395-ФЗ** — отсутствие обоснований продления сроков ответов
- **Спорная методика расчёта сроков по 115-ФЗ**

### 2.3 Зоны повышенного внимания
- Высокая частота запросов от департаментов ЦБ РФ
- Процедуры реабилитации клиентов по ФЗ-115

---

## Рабочие команды

```bash
# Быстрый тест (5 папок)
python3 analyze_cb_docs.py --input-dir цб --output cb_report.md --limit 5

# Полный анализ (все 75 папок)
python3 analyze_cb_docs.py --input-dir цб --output cb_report_full.md

# С OCR для сканов
python3 analyze_cb_docs.py --input-dir цб --output cb_report.md --ocr

# С темой анализа
python3 analyze_cb_docs.py --input-dir цб --output fz115_report.md --theme "ФЗ-115 compliance"
```

---

## Переменные окружения

```bash
export JPY_API_TOKEN=your_token_here
export GC_API_URL=http://liveaccess/v1/gc
```

**Проверка API:**
```bash
curl -X POST $GC_API_URL/chat/completions \
  -H "Authorization: Bearer $JPY_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"model":"Qwen3.5-397b","messages":[{"role":"user","content":"test"}],"max_tokens":50}'
```

---

### Альтернативные источники данных

Если ZIP-архивы содержат `.ppdf`:

1. **Реестр документов XLSX** (`Реестр1.xlsx` в папке `цб/`) — 69 записей с метаданными и пересказами от GigaChat
   - Колонки: ID, номера, даты, авторы, получатели, urgency, title, summary, full_text
   - Анализ через openpyxl/pandas напрямую

2. **XLSX-приложения в папках ЦБ** — ЧИТАЮТСЯ openpyxl (это не сканы!)
   - "Реестр рекомендованных мероприятий*.xlsx" — реестры нарушений, выданных ЦБ банку (кол.: Нарушенная норма, Краткое описание нарушения, Рекомендация, Исполнение)
   - "Сведения о жалобах клиентов*.xlsx" — квартальные отчёты по жалобам
   - ⚠️ `analyze_cb_docs.py` обрабатывает ТОЛЬКО pdf/docx и ложно помечает xlsx как "empty/scan (no OCR)" — на самом деле xlsx читаются нормально через openpyxl

3. **Прямой доступ к SberDocs** — через API (требует авторизации)

---

## Полный анализ папки цб/ (pipeline v2.0.0, обновлено 09.10.2026)

**Самодостаточный пайплайн** в `doccheck-analyzer/scripts/` — один запуск, формат
(zip/папки) определяется автоматически. Полное описание — в `SKILL.md`.

```bash
python3 doccheck-analyzer/scripts/run_pipeline.py /path/to/папка \
    [--out DIR] [--theme "ТЕМА"] [--no-ocr] [--skip-analysis] \
    [--include-text-in-registry] [--ocr-cache existing.json]
```

**Этапы (порядок жёсткий):**
1. **ОБНАРУЖЕНИЕ** — реестр (XLSX) + (ZIP | папки) — `extract_docs.discover()`
2. **ПАРСИНГ** — PDF/DOCX/XLSX; PDF без текста (<10 симв.) → OCR (EasyOCR ru)
3. **ПЕРЕСКАЗЫ** — документы без пересказа в реестре → LLM (кэш `summaries_*.json`)
4. **РЕЕСТР** — `enriched_registry.xlsx`: колонки реестра + `Пересказ (обогашён)`,
   `Источник пересказа` (реестр/сгенерирован/нет), `Метод парсинга`, `Кол-во файлов`
5. **АНАЛИЗЫ** — `analysis.py`: `analyze_risks()` (Тип 1) + `analyze_topics()` (Тип 2),
   каждый с темой/без
6. **ОТЧЁТ** — `report_final.md` (сводка + оба анализа)

**Модули:** `ocr_utils.py` (OCR: GPU/CPU, кэш), `extract_docs.py` (извлечение +
discover + resolve_ocr), `summaries.py` (LLM-пересказы), `registry_enrich.py`
(обогащение/выгрузка реестра), `analysis.py` (2 типа анализа), `run_pipeline.py`
(оркестратор + CLI).

**Выгрузки** (в `<input>/_doccheck_out/`): `enriched_registry.xlsx`, `docs.json`,
`summaries_*.json`, `ocr_cache_*.json`, `analysis_risks.{json,md}`,
`analysis_topics.{json,md}`, `report_final.md`. Имена кэшей — хэш папки-источника.

**Резюмируемость:** все LLM-вызовы и OCR кэшируются на диск после каждого элемента —
можно убить/перезапустить, продолжится с места остановки. `--ocr-cache` подгружает
существующий кэш (переиспользование распознанного без повторного OCR).

### OCR — модели EasyOCR с NFS (внешний интернет недоступен)
- `nfs/mvp/JaidedAI_EasyOCR_1-6-1_cyrillic_g2.zip` → `~/.EasyOCR/model/cyrillic_g2.pth`
- `nfs/mvp/craft_mlt_25k.zip` → `~/.EasyOCR/model/craft_mlt_25k.pth`
- `unzip -o -j <zip> -d ~/.EasyOCR/model/`
- **GPU занят** (A100 92%): easyocr падает «CUDA device busy» — `pick_device()` берёт
  GPU только если свободно >8ГБ, иначе CPU (`CUDA_VISIBLE_DEVICES=""`).
- **OCR на CPU медленный** (~10–1000 с/страница) — кэш `ocr_cache_*.json`.

**Pitfall — reasoning Qwen3.5-397b:** `content` пустой при малом `max_tokens`
(reasoning-токены). Риски: 8000, темы: 6000, пересказы: 2000.

**Pitfall — сопоставление:** папки `ЦА-662-исх_N`, реестр `ЦА-662-исх/N` —
регулярка `исх[/_](\d+)`, сопоставление по doc_id и по номеру.

**Pitfall — XLSX:** реестры/отчёты `.xlsx` читаются openpyxl (не сканы).
**Pitfall — .ppdf:** защищённый формат Сбера, не читается — пропустить.

**Реальные результаты (папка `цб`, 75 папок, 09.10.2026, проверено полным прогоном):**
- Извлечено 228 документов (180 text + 37 xlsx + 11 OCR), 75 папок → 75 документов.
- Реестр 69 записей; пересказы: 59 из реестра + 10 сгенерировано LLM (из них 3 —
  повторная генерация после таймаута). `enriched_registry.xlsx` — 69 строк.
- `report_final.md` ~38 КБ: сводка + анализ рисков (15+15+14+6 по категориям) +
  тематика (20 тем, 14 авторов, помесячная динамика).
- Кэш OCR переиспользован (`--ocr-cache`) — повторный прогон ~10 мин вместо 2ч.
- ⚠️ **Качество OCR:** для чётких сканов — хорошо; для повёрнутых/низкокачественных
  (например, «Заявление на выпуск карты») — текст частично нечитаем. Файл всё равно
  получает текстовый слой и попадает в анализ, но для таких сканов нужна рутация/улучшение.

---

## Git history

- Commit `e82b4a3` — добавлен `doccheck_batch.py`
- Commit `97f3800` — обновлён скилл до v1.0.2 (3 режима работы)
- Полный анализ: `cb_report_full.md` (75 папок, 180 документов)
- 09.10.2026: полный анализ через pipeline cb_extract/cb_analyze/cb_report_build -> `cb_report_final.md`
