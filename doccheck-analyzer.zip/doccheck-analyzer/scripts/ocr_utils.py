"""
OCR-утилиты DocCheck.
Автовыбор GPU/CPU (GPU только если свободно >8ГБ, иначе CPU),
локальные модели EasyOCR (внешний интернет недоступен), кэш распознавания.

Модели ставятся вручную в ~/.EasyOCR/model/ (см. SKILL.md, раздел «OCR»).
"""
import os
import io
import json
import time
import subprocess

# --- Выбрать устройство ПЕРЕД импортом torch/easyocr ---
def pick_device(min_free_mb=8000):
    """Возвращает ('gpu', free_mb) если GPU свободен, иначе ('cpu', 0)."""
    try:
        out = subprocess.check_output(
            ['nvidia-smi', '--query-gpu=memory.free', '--format=csv,noheader,nounits'],
            text=True, timeout=10).strip().split('\n')
        free = max(int(x) for x in out if x.strip())
        if free > min_free_mb:
            return 'gpu', free
    except Exception:
        pass
    return 'cpu', 0


def force_cpu():
    """Принудительно CPU — если GPU занят, easyocr падает с 'CUDA device busy'."""
    os.environ['CUDA_VISIBLE_DEVICES'] = ''


# Лягкий ленивый загрузчик reader (один раз на процесс)
_READER = None
def get_ocr_reader(use_gpu=False, langs=('ru',), model_dir=None):
    """Возвращает EasyOCR Reader или None (если библиотеки/модели не установлены)."""
    global _READER
    if _READER is not None:
        return _READER
    try:
        import easyocr
        model_dir = model_dir or os.path.expanduser('~/.EasyOCR/model')
        if not (os.path.exists(os.path.join(model_dir, 'craft_mlt_25k.pth'))
                and any(f.endswith('.pth') and 'cyrillic' in f for f in os.listdir(model_dir))):
            print(f"[ocr] модели не найдены в {model_dir} — OCR недоступен")
            return None
        t0 = time.time()
        _READER = easyocr.Reader(list(langs),
                                 model_storage_directory=model_dir,
                                 download_enabled=False,
                                 gpu=bool(use_gpu))
        print(f"[ocr] reader загружен за {time.time()-t0:.1f}с (gpu={use_gpu})")
        return _READER
    except Exception as e:
        print(f"[ocr] ошибка загрузки: {e}")
        return None


def ocr_pdf(pdf_path, reader, zoom=1.0, contrast=1.5):
    """Распознаёт текст PDF (страница за страницей). Возвращает str."""
    import fitz
    import numpy as np
    from PIL import Image, ImageEnhance
    doc = fitz.open(pdf_path)
    text = ''
    for pn in range(len(doc)):
        page = doc.load_page(pn)
        pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom))
        img = Image.open(io.BytesIO(pix.tobytes('png')))
        if img.mode != 'RGB':
            img = img.convert('RGB')
        if contrast and contrast != 1.0:
            img = ImageEnhance.Contrast(img).enhance(contrast)
        res = reader.readtext(np.array(img), detail=0, paragraph=True)
        text += ' '.join(res) + '\n'
    doc.close()
    return text.strip()


# --- Кэш OCR (резюмируемость) ---
def load_cache(path):
    if os.path.exists(path):
        try:
            return json.load(open(path, encoding='utf-8'))
        except Exception:
            return {}
    return {}


def save_cache(path, obj):
    tmp = path + '.tmp'
    json.dump(obj, open(tmp, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    os.replace(tmp, path)
