"""
Анализ документов LLM — два независимых типа, каждый работает с темой или без.

Тип 1. Анализ рисков и гипотез (chunk по 30) — риски по 4 категориям, сильные
       стороны, слабости, рекомендации, примеры документов.
       Функция: analyze_risks() → JSON-агрегация + markdown-отчёт.
Тип 2. Общий тематический анализ (chunk по 50) — тематическое распределение,
       авторы, помесячная динамика, тренды срочности.
       Функция: analyze_topics() → markdown-отчёт.

Результаты кэшируются в JSON (резюмируемо). LLM — GigaChat API (см. summaries.py).
"""
import os
import re
import json
import time
from collections import Counter
from summaries import call_llm

CHUNK_RISKS = 30
CHUNK_TOPICS = 50
MAX_SUMMARY = 500
MAX_TEXT_IN_CHUNK = 2500  # символов полного текста на документ в чанке


# ---------- Утилиты ----------
def _extract_json(text):
    if not text:
        return None
    for pat in [r'```json\s*(\{.*?\})\s*```', r'```\s*(\{.*?\})\s*```']:
        m = re.search(pat, text, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(1))
            except Exception:
                pass
    m = re.search(r'(\{.*\})', text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except Exception:
            pass
    return None


def _norm(s):
    return re.sub(r'\s+', '', s or '').lower()


def _build_doc_payload(doc, reg_by_id, summaries):
    """
    Формирует компактный payload документа для чанка анализа.
    doc: {doc_id, folder, file, date, type, text, ...}
    """
    did = _norm(doc['doc_id'])
    # номерный ключ (папки «исх_19» ↔ реестр «исх/19»)
    m = re.search(r'исх[/_](\d+)', (doc['doc_id'] or '').lower())
    r = reg_by_id.get(did, {})
    if not r and m:
        r = reg_by_id.get(f"__num_{m.group(1)}", {})
    p = {
        'doc_id': doc['doc_id'],
        'date': doc.get('date', ''),
        'file': doc.get('file', ''),
        'title': (r.get('title') or '').strip(),
        'author': (r.get('author') or '').strip(),
        'urgency': (r.get('urgency') or '').strip(),
    }
    summary = (r.get('summary') or '').strip()
    src = 'реестр'
    if len(summary) < 30:
        g = (summaries.get(did) or '').strip()
        if not g and m:
            g = (summaries.get(f"__num_{m.group(1)}") or '').strip()
        if g and not g.startswith('[не удалось]'):
            summary, src = g, 'сгенерирован'
    if summary and not summary.startswith('[не удалось]'):
        p['summary'] = summary[:MAX_SUMMARY]
        p['summary_source'] = src
    if doc.get('text'):
        p['text_excerpt'] = doc['text'][:MAX_TEXT_IN_CHUNK]
    return p


# ---------- Тип 1: Анализ рисков и гипотез ----------
_RISKS_PROMPT = """Ты — ведущий аудитор внутреннего контроля банка.
Твоя задача — проанализировать документы проверяемого подразделения{theme_instr} и выявить факты, указывающие на:

1. Операционные риски — сбои, ошибки, инциденты, нарушения регламентов.
2. Недостатки процессов — узкие места, неэффективные процедуры, отсутствие контроля.
3. Кадровые риски — недостаток компетенций, высокая нагрузка, нарушения дисциплины.
4. Признаки мошенничества или злоупотреблений — конфликт интересов, подозрительные операции, аномалии.
5. Сильные стороны — примеры эффективного контроля и корректного выполнения процедур.
6. Рекомендации — что аудиторам стоит проверить или улучшить по итогам анализа документов.

ВАЖНО:
- Анализ проводится для проверяемого подразделения, а не для банка в целом.
- Не формулируй рекомендации «на уровне всего банка».
- Извлекай только факты из документов, не додумывай.
- Не включай временные и поведенческие паттерны.

Данные (чанк документов):
{chunk_json}

Формат ответа — строгий JSON:
{{
  "risks": {{
    "operational": ["..."],
    "process": ["..."],
    "personnel": ["..."],
    "fraud_indicators": ["..."]
  }},
  "strengths": ["..."],
  "weaknesses": ["..."],
  "recommendations": ["..."],
  "themes": {{"main_topics": ["..."], "keywords": {{"слово": 1}}}},
  "urgency_stats": {{"срочный": 0, "несрочный": 0}},
  "authors_mentioned": ["..."],
  "document_examples": [
    {{
      "document_id": "номер",
      "title": "название",
      "author": "автор",
      "date": "дата",
      "summary_excerpt": "краткая выдержка",
      "category": "operational_risk|process_weakness|personnel_risk|fraud_red_flag|strength|general",
      "linked_finding": "к какому риску относится пример"
    }}
  ]
}}

Требования к примерам:
- Для каждой категории рисков добавь 2-5 примеров документов.
- В linked_finding укажи, какой риск подтверждает документ.
- Если примеров мало, включи документы с category "general".
"""


def analyze_risks(docs, reg_by_id, summaries, theme=None, cache=None,
                  cache_path=None, progress=None):
    """
    Тип 1: анализ рисков. Возвращает (aggregated, report_md).
    cache: dict {'chunks': {chunk_idx: result}} — кэш по чанкам (резюмируемо).
    """
    if cache is None:
        cache = {}
    if 'chunks' not in cache:
        cache['chunks'] = {}

    # Индекс: несколько файлов одной папки = один документ
    by_folder = {}
    for d in docs:
        by_folder.setdefault(d['folder'], []).append(d)

    folders = sorted(by_folder.keys(), key=lambda f: (
        (next((d['date'] for d in by_folder[f] if d['date']), '0000'), f)))

    payloads = []
    for f in folders:
        # объединяем файлы папки: summary/text из первого, файлы — список
        main = by_folder[f][0]
        p = _build_doc_payload(main, reg_by_id, summaries)
        p['files'] = [d['file'] for d in by_folder[f]]
        payloads.append(p)

    chunks = [payloads[i:i + CHUNK_RISKS] for i in range(0, len(payloads), CHUNK_RISKS)]
    aggregated = {
        'theme': theme,
        'risks': {'operational': [], 'process': [], 'personnel': [], 'fraud_indicators': []},
        'strengths': [], 'weaknesses': [], 'recommendations': [],
        'themes': {'main_topics': [], 'keywords': {}},
        'urgency_stats': {}, 'authors': set(),
        'examples': [], 'input_documents_count': len(payloads),
        'chunks_count': len(chunks),
    }

    for ci, chunk in enumerate(chunks):
        if ci in cache['chunks']:
            cr = cache['chunks'][ci]
            print(f"  [риски] чанк {ci+1}/{len(chunks)} — из кэша")
        else:
            theme_instr = f" по теме '{theme}'" if theme else ''
            prompt = _RISKS_PROMPT.format(theme_instr=theme_instr,
                                          chunk_json=json.dumps(chunk, ensure_ascii=False, default=str, indent=1))
            resp = call_llm(prompt, max_tokens=8000, timeout=240, retries=2,
                            system='Ты опытный аудитор банка. Анализируй документы, выявляй риски, опирайся только на факты из предоставленных документов. Отвечай на русском.')
            cr = _extract_json(resp) if resp else None
            if cr is None:
                print(f"  [риски] чанк {ci+1}/{len(chunks)} — ОШИБКА/пустой ответ, пропускаю")
                continue
            cache['chunks'][ci] = cr
            if cache_path:
                from summaries import save_cache
                save_cache(cache_path, cache)

        # агрегация
        for k in aggregated['risks']:
            aggregated['risks'][k].extend(cr.get('risks', {}).get(k, []))
        aggregated['strengths'].extend(cr.get('strengths', []))
        aggregated['weaknesses'].extend(cr.get('weaknesses', []))
        aggregated['recommendations'].extend(cr.get('recommendations', []))
        aggregated['themes']['main_topics'].extend(cr.get('themes', {}).get('main_topics', []))
        for w, f_ in (cr.get('themes', {}).get('keywords') or {}).items():
            try:
                aggregated['themes']['keywords'][w] = aggregated['themes']['keywords'].get(w, 0) + int(f_)
            except Exception:
                pass
        for k, v in (cr.get('urgency_stats') or {}).items():
            try:
                aggregated['urgency_stats'][k] = aggregated['urgency_stats'].get(k, 0) + int(v)
            except Exception:
                pass
        aggregated['authors'].update(cr.get('authors_mentioned', []))
        for ex in cr.get('document_examples', []):
            aggregated['examples'].append({
                'doc_id': str(ex.get('document_id') or ''),
                'title': ex.get('title', 'Без названия'),
                'author': ex.get('author', 'н/д'),
                'date': ex.get('date', 'н/д'),
                'summary_excerpt': str(ex.get('summary_excerpt') or '')[:120],
                'category': ex.get('category', 'general'),
                'linked_finding': ex.get('linked_finding', ''),
            })
        if progress:
            progress(ci + 1, len(chunks))

    aggregated['authors'] = sorted(aggregated['authors'])
    report = _render_risks_report(aggregated)
    return aggregated, report


def _render_risks_report(a):
    theme = f" по теме «{a['theme']}»" if a.get('theme') else ''
    lines = [f"# Анализ рисков и гипотез{theme}\n",
             f"**Документов в анализе:** {a['input_documents_count']} | **Чанков:** {a['chunks_count']}\n"]
    for key, label in [('operational', 'Операционные риски'),
                       ('process', 'Недостатки процессов'),
                       ('personnel', 'Кадровые риски'),
                       ('fraud_indicators', 'Признаки мошенничества/злоупотреблений')]:
        items = a['risks'].get(key, [])
        lines.append(f"## {label} ({len(items)})\n")
        for it in items[:30]:
            lines.append(f"- {it}")
        if not items:
            lines.append("*(не выявлены)*")
        lines.append('')
    lines.append(f"## Сильные стороны ({len(a['strengths'])})\n")
    lines += [f"- {s}" for s in a['strengths'][:20]] or ['*(нет)']
    lines.append('')
    lines.append(f"## Области для улучшения ({len(a['weaknesses'])})\n")
    lines += [f"- {w}" for w in a['weaknesses'][:20]] or ['*(нет)']
    lines.append('')
    lines.append(f"## Рекомендации для проверки ({len(a['recommendations'])})\n")
    lines += [f"- {r}" for r in a['recommendations'][:40]] or ['*(нет)']
    lines.append('')
    topics = Counter(a['themes']['main_topics'])
    if topics:
        lines.append("## Основные темы\n")
        lines += [f"- {t}: {c}" for t, c in topics.most_common(15)]
        lines.append('')
    if a['examples']:
        lines.append("## Примеры документов\n")
        for ex in a['examples'][:25]:
            lines.append(f"- **{ex['title']}** (№{ex['doc_id']}, {ex['author']}, {ex['date']}) — `{ex['category']}`")
            if ex['linked_finding']:
                lines.append(f"  *{ex['linked_finding']}*")
    if a.get('authors'):
        lines.append(f"\n## Авторы: {', '.join(a['authors'][:15])}")
    return '\n'.join(lines)


# ---------- Тип 2: Общий тематический анализ ----------
_TOPICS_PROMPT = """Ты — аналитик банковской документации. Проанализируй реестр документов подразделения (чанк данных){theme_instr}.

Задача: выделить основные темы, категории и тренды по следующим документам:

{chunk_json}

Сформируй аналитический отчёт в формате JSON:
{{
    "topics": [{{"topic": "название темы", "count": частота}}],
    "authors": [{{"author": "имя", "doc_count": количество, "main_topics": ["тема1", "тема2"]}}],
    "time_stats": {{
        "monthly": [{{"month": "YYYY-MM", "count": число}}],
        "urgent_trend": "описание тренда срочных документов"
    }},
    "recommendations": "краткие рекомендации по оптимизации"
}}

Важно:
- Для каждой темы укажи, сколько документов к ней относится (частота).
- Для авторов перечисли их основные темы (не более 3).
- Временная статистика: помесячная разбивка (если есть даты).
- Ответ — только JSON, без markdown.
"""


def analyze_topics(docs, reg_by_id, summaries, theme=None, cache=None,
                   cache_path=None, progress=None):
    """
    Тип 2: тематический анализ. Возвращает (result_dict, report_md).
    cache: dict {'chunks': {chunk_idx: result}} — кэш по чанкам.
    """
    if cache is None:
        cache = {}
    if 'chunks' not in cache:
        cache['chunks'] = {}

    # один документ = одна папка
    by_folder = {}
    for d in docs:
        by_folder.setdefault(d['folder'], []).append(d)

    payloads = []
    for f in sorted(by_folder.keys()):
        main = by_folder[f][0]
        p = _build_doc_payload(main, reg_by_id, summaries)
        p['files'] = [d['file'] for d in by_folder[f]]
        payloads.append(p)

    # фильтруем: нужны title или summary
    valid = [p for p in payloads if p.get('title') or p.get('summary')]
    chunks = [valid[i:i + CHUNK_TOPICS] for i in range(0, len(valid), CHUNK_TOPICS)]

    topic_counter = Counter()
    authors_data = {}
    monthly_counter = Counter()
    urgent_trends = []
    recs = []

    for ci, chunk in enumerate(chunks):
        if ci in cache['chunks']:
            cr = cache['chunks'][ci]
            print(f"  [темы] чанк {ci+1}/{len(chunks)} — из кэша")
        else:
            theme_instr = f" по теме '{theme}'" if theme else ''
            prompt = _TOPICS_PROMPT.format(theme_instr=theme_instr,
                                           chunk_json=json.dumps(chunk, ensure_ascii=False, default=str, indent=1))
            resp = call_llm(prompt, max_tokens=6000, timeout=240, retries=2)
            cr = _extract_json(resp) if resp else None
            if cr is None:
                print(f"  [темы] чанк {ci+1}/{len(chunks)} — ОШИБКА, пропускаю")
                continue
            cache['chunks'][ci] = cr
            if cache_path:
                from summaries import save_cache
                save_cache(cache_path, cache)

        for t in cr.get('topics', []):
            if isinstance(t, dict):
                tp, cnt = t.get('topic', ''), t.get('count', 0)
                if tp and isinstance(cnt, (int, float)) and cnt > 0:
                    topic_counter[tp] += int(cnt)
        for a in cr.get('authors', []):
            if not isinstance(a, dict):
                continue
            auth = a.get('author', '')
            if not auth:
                continue
            if auth not in authors_data:
                authors_data[auth] = {'doc_count': 0, 'topics_counter': Counter()}
            authors_data[auth]['doc_count'] += a.get('doc_count', 0)
            for tp in (a.get('main_topics') or [])[:3]:
                if tp:
                    authors_data[auth]['topics_counter'][tp] += 1
        ts = cr.get('time_stats', {}) or {}
        for m in ts.get('monthly', []):
            if isinstance(m, dict):
                mo, cnt = m.get('month', ''), m.get('count', 0)
                if mo and isinstance(cnt, (int, float)) and cnt > 0:
                    monthly_counter[mo] += int(cnt)
        if ts.get('urgent_trend'):
            urgent_trends.append(ts['urgent_trend'])
        if cr.get('recommendations'):
            recs.append(str(cr['recommendations']))
        if progress:
            progress(ci + 1, len(chunks))

    result = {
        'theme': theme,
        'topics': topic_counter.most_common(30),
        'authors': [{'author': k, 'doc_count': v['doc_count'],
                     'main_topics': [t for t, _ in v['topics_counter'].most_common(3)]}
                    for k, v in sorted(authors_data.items(), key=lambda x: -x[1]['doc_count'])[:20]],
        'monthly': sorted(monthly_counter.items()),
        'urgent_trends': urgent_trends,
        'recommendations': recs,
        'total': len(valid),
        'chunks': len(chunks),
    }
    return result, _render_topics_report(result)


def _render_topics_report(r):
    theme = f" по теме «{r['theme']}»" if r.get('theme') else ''
    lines = [f"# Общий тематический анализ документов{theme}\n",
             f"**Документов:** {r['total']} | **Чанков:** {r['chunks']}\n"]
    lines.append("## 1. Тематическое распределение\n")
    if r['topics']:
        lines += [f"- {t[0][0].upper() + t[0][1:] if t[0] else t[0]}: {t[1]}" for t in r['topics'][:20]]
    else:
        lines.append("*(темы не выделены)*")
    lines.append('')
    lines.append("## 2. Анализ авторов\n")
    if r['authors']:
        for a in r['authors'][:15]:
            tp = ', '.join(a['main_topics']) if a['main_topics'] else 'нет данных'
            lines.append(f"- **{a['author']}**: {a['doc_count']} док., основные темы: {tp}")
    else:
        lines.append("*(нет данных об авторах)*")
    lines.append('')
    lines.append("## 3. Временная динамика\n")
    if r['monthly']:
        for mo, cnt in r['monthly']:
            lines.append(f"- {mo}: {cnt} док.")
    else:
        lines.append("*(нет данных о датах)*")
    if r['urgent_trends']:
        lines.append("\n**Тренды срочных документов:**")
        lines += [f"- {t}" for t in r['urgent_trends'][:3]]
    if r['recommendations']:
        lines.append("\n## 4. Рекомендации\n")
        lines += [f"- {x}" for x in r['recommendations'][:5]]
    return '\n'.join(lines)
