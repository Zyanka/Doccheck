"""
Обогащение и выгрузка реестра.

Реестр (XLSX с колонкой document_id) обогащается результатами парсинга:
  - Метод парсинга — по файлам: «Письмо.pdf: text | Заявление.pdf: ocr (80с)»
  - Кол-во файлов
  - Пересказ — из реестра; если его нет — сгенерированный (этап пересказов)
  - Источник пересказа — «реестр» / «сгенерирован» / «нет»

Итог — enriched_registry.xlsx, который пользователь видит сразу после
предобработки (до запуска LLM-анализов).
"""
import os
import re
import json

try:
    import openpyxl
    from openpyxl import Workbook
    from openpyxl.utils import get_column_letter
except ImportError:
    openpyxl = None


def read_registry(path):
    """Читает реестр XLSX -> (header, rows list[dict])."""
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    header = [str(h).strip() if h is not None else f'col{i}' for i, h in enumerate(rows[0])]
    out = []
    for r in rows[1:]:
        if all(v is None or str(v).strip() == '' for v in r):
            continue
        out.append({k: (str(v).strip() if v is not None else '') for k, v in zip(header, r)})
    wb.close()
    return header, out


def _num_of(doc_id):
    """Номер из document_id: 'ЦА-662-исх/10' или 'ЦА-662-исх_10' -> 10."""
    m = re.search(r'исх[/_](\d+)', re.sub(r'\s+', '', doc_id or '').lower())
    return int(m.group(1)) if m else None


def build_folder_map(docs):
    """doc_id -> [docs]; ключи: нормализованный doc_id и номер."""
    m = {}
    for d in docs:
        m.setdefault(d['doc_id'], []).append(d)
        n = _num_of(d['doc_id'])
        if n is not None:
            m.setdefault(f"__num_{n}", []).append(d)
    return m


def enrich_registry(header, reg, docs, summaries, out_path,
                    include_full_text=False, max_text=2000):
    """
    Обогащает реестр и выгружает в XLSX.
    summaries: {document_id (как в реестре): summary} — сгенерированные.
    Возвращает list обогащённых строк.
    """
    from summaries import is_empty_summary

    fmap = build_folder_map(docs)
    enriched = []
    for r in reg:
        did = r.get('document_id', '')
        # сопоставление: точный doc_id или по номеру
        my_docs = fmap.get(did, [])
        if not my_docs:
            n = _num_of(did)
            if n is not None:
                my_docs = fmap.get(f"__num_{n}", [])

        methods = [f"{d['file']}: {d['method']}" for d in my_docs
                   if len(f"{d['file']}: {d['method']}") < 90]
        if not methods:
            methods = ['не найдено']

        reg_sum = (r.get('summary') or '').strip()
        if is_empty_summary(reg_sum):
            g = (summaries.get(did) or '').strip()
            if g and not g.startswith('[не удалось]'):
                reg_sum, src = g, 'сгенерирован'
            else:
                src = 'нет'
        else:
            src = 'реестр'

        row = {}
        for col in header:
            row[col] = r.get(col, '')
        row['Пересказ (обогашён)'] = reg_sum
        row['Источник пересказа'] = src
        row['Метод парсинга'] = ' | '.join(methods)
        row['Кол-во файлов'] = len(my_docs)
        if include_full_text and my_docs:
            full = '\n\n'.join(d['text'][:max_text] for d in my_docs)
            row['Текст (извлечение)'] = full[:max_text * 2]
        enriched.append(row)

    if openpyxl is None:
        raise RuntimeError("openpyxl не установлен")
    wb = Workbook()
    ws = wb.active
    ws.title = 'Реестр'
    cols = list(header) + ['Пересказ (обогашён)', 'Источник пересказа',
                            'Метод парсинга', 'Кол-во файлов']
    if include_full_text:
        cols.append('Текст (извлечение)')
    ws.append(cols)
    for row in enriched:
        ws.append([row.get(c, '') for c in cols])
    # ширина колонок
    for i, c in enumerate(cols, 1):
        width = min(max(len(str(c)) + 2, 12), 60)
        if c in ('Пересказ (обогашён)', 'Текст (извлечение)'):
            width = 60
        if c == 'Метод парсинга':
            width = 45
        ws.column_dimensions[get_column_letter(i)].width = width
    wb.save(out_path)
    return enriched
