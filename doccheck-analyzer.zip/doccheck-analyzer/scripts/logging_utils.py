"""
DocCheck logging — совместимый с Streamlit-версией (document_analyzer.py).

Формат: JSONL (одна JSON-запись на строку), поля:
  {"timestamp": ISO, "event": "event_type", "details": {...}}

Лог-файл: /tmp/sberdocs_{user}_{date}.log
HDFS:      hdfs://arnsdpsbx/tmp/sberdocs_logs/{user}/{date}/

Периодическая выгрузка в HDFS каждые N секунд (через threading.Timer).
Выгрузка при завершении (atexit).
Требует действующий Kerberos-билет для HDFS.
"""

import os
import json
import subprocess
import threading
import atexit
from datetime import datetime
from pathlib import Path

# Глобальные переменные (аналогично document_analyzer.py)
_LOG_FILE = None
_LOG_USER = None
_UPLOAD_INTERVAL = 100  # секунд
_UPLOAD_THREAD = None


def init_logging(username: str = None):
    """
    Инициализация логирования.
    username: если None, берётся из SB_LOGIN или USER.
    """
    global _LOG_FILE, _LOG_USER

    if username is None:
        username = os.environ.get("SB_LOGIN") or os.environ.get("USER") or "unknown"

    date_str = datetime.now().strftime("%Y%m%d")
    log_path = f"/tmp/sberdocs_{username}_{date_str}.log"

    if not os.path.exists(log_path):
        Path(log_path).touch()

    _LOG_USER = username
    _LOG_FILE = log_path

    log_event("session_start", {"login": username, "source": "pipeline"})
    _schedule_hdfs_upload(_UPLOAD_INTERVAL)


def log_event(event_type: str, details: dict = None):
    """
    Записывает событие в лог-файл (JSONL).
    Совместимо с document_analyzer.py — тот же формат.
    """
    if _LOG_FILE is None:
        return
    record = {
        "timestamp": datetime.now().isoformat(),
        "event": event_type,
        "details": details or {}
    }
    try:
        with open(_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except Exception:
        pass  # логирование не должно ронять пайплайн


def upload_log_to_hdfs():
    """Выгрузка лог-файла в HDFS (аналог document_analyzer.py)."""
    if _LOG_FILE is None or not os.path.exists(_LOG_FILE):
        return
    try:
        date_str = datetime.now().strftime("%Y-%m-%d")
        hdfs_dir = f"hdfs://arnsdpsbx/tmp/sberdocs_logs/{_LOG_USER}/{date_str}"
        subprocess.run(["hdfs", "dfs", "-mkdir", "-p", hdfs_dir], check=False)
        subprocess.run(["hdfs", "dfs", "-put", "-f", _LOG_FILE, hdfs_dir + "/"], check=False)
    except Exception as e:
        print(f"  [log] Ошибка выгрузки лога в HDFS: {e}")


def _schedule_hdfs_upload(interval: int):
    """Периодическая выгрузка лога в HDFS."""
    upload_log_to_hdfs()
    global _UPLOAD_THREAD
    _UPLOAD_THREAD = threading.Timer(interval, _schedule_hdfs_upload, args=[interval])
    _UPLOAD_THREAD.daemon = True
    _UPLOAD_THREAD.start()


# Автоматическая выгрузка при завершении
atexit.register(upload_log_to_hdfs)