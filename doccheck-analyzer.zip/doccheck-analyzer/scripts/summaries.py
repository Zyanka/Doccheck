"""
Генерация пересказов документов через LLM (GigaChat API).

Пересказ создаётся, только если в реестре у документа его нет (или указана
отписка типа «пересказ отсутствует»), но есть извлечённый текст.
Результаты кэшируются в JSON (резюмируемо: kill/перезапуск не повторяет работу).
"""
import os
import re
import json
import time
import requests

MODEL = os.environ.get('DC_MODEL', 'Qwen3.5-397b')
API_URL = os.environ.get('GC_API_URL', 'http://liveaccess/v1/gc')
API_TOKEN = os.environ.get('JPY_API_TOKEN', '')


def call_llm(prompt, max_tokens=2000, timeout=120, retries=2,
             system='Ты — аналитик банковской документации.'):
    """Возвращает str ответа или None. Обрабатывает reasoning-модели (пустой content)."""
    if not API_TOKEN:
        return None
    url = API_URL.rstrip('/') + '/chat/completions'
    for attempt in range(retries + 1):
        try:
            r = requests.post(
                url,
                headers={'Authorization': f'Bearer {API_TOKEN}',
                         'Content-Type': 'application/json'},
                json={'model': MODEL,
                      'messages': [{'role': 'system', 'content': system},
                                   {'role': 'user', 'content': prompt}],
                      'max_tokens': max_tokens, 'temperature': 0.3},
                timeout=timeout)
            r.raise_for_status()
            m = r.json()['choices'][0]['message']
            content = (m.get('content') or '').strip()
            # reasoning-модель: если content пуст, но есть reasoning_content —
            # финальный ответ отсутствует (недостаток max_tokens), не используем
            if content:
                return content
        except Exception as e:
            print(f"  [llm retry {attempt+1}] {e}")
            time.sleep(5)
    return None


def is_empty_summary(val, min_length=30):
    """Считает ли значение «пересказа нет» (пусто, коротко или отписка-маркер)."""
    if val is None:
        return True
    s = str(val).strip()
    if not s:
        return True
    s_lower = s.lower()
    markers = [
        'пересказ отсутствует', 'отсутствует пересказ', 'пересказ не сформирован',
        'не сформирован', 'не указано', 'не предоставлен', 'нет данных',
        'нет пересказа', 'пересказ недоступен', 'недоступен', 'не удалось',
        'не смог', 'н/д', 'нет информации', 'информация отсутствует',
        'документ конфиденциален', 'конфиденциально', 'нет', 'отсутствует',
    ]
    if len(s) < min_length:
        return True
    if any(m in s_lower for m in markers):
        return True
    import re
    if re.fullmatch(r'[\s\W\d_]+', s_lower):
        return True
    return False


def load_cache(path):
    if os.path.exists(path):
        try:
            return json.load(open(path, encoding='utf-8'))
        except Exception:
            return {}
    return {}


def save_cache(path, obj):
    tmp = path + '.tmp'
    json.dump(obj, open(tmp, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def generate_summaries(reg, doc_full_text_by_id, cache, cache_path,
                       max_text_chars=8000, progress=None):
    """
    Генерирует пересказы для документов реестра без пересказа.

    reg: list[dict] — записи реестра (с колонками document_id/title/summary)
    doc_full_text_by_id: dict {document_id (norm): 'полный текст из парсинга'}
    cache: dict {document_id: summary} — кэш (передаётся и обновляется на месте)
    cache_path: путь для сохранения кэша

    Возвращает (count_generated, cache).
    """
    generated = 0
    todo = []
    _printed_retry = set()
    for r in reg:
        did = r.get('document_id', '')
        if not did:
            continue
        # пропускаем: уже есть валидный пересказ в кэше ИЛИ в реестре
        cached = (cache.get(did) or '').strip()
        if cached and not cached.startswith('[не удалось]'):
            continue
        if cached.startswith('[не удалось]') and did not in _printed_retry:
            print(f"  [summaries] повторная генерация (ранее не удалось): {did}")
            _printed_retry.add(did)
        if not is_empty_summary(r.get('summary')):
            continue
        # поиск полного текста: по нормализованному id и по номеру
        # (папки «исх_19», реестр «исх/19»)
        norm = _norm(did)
        m = re.search(r'исх[/_](\d+)', (did or '').lower())
        keys = [norm] + ([f"__num_{m.group(1)}"] if m else [])
        full_text = ''
        for k in keys:
            ft = (doc_full_text_by_id.get(k) or '').strip()
            if len(ft) > len(full_text):
                full_text = ft
        if len(full_text) > 50:
            # дедупликация: одно и то же document_id не генерируем дважды
            if not any(t['document_id'] == did for t in todo):
                todo.append({'document_id': did, 'title': r.get('title', ''),
                             'full_text': full_text})
    total = len(todo)
    if total == 0:
        print(f"[summaries] генерировать нечего (всё уже есть): {len(cache)} в кэше")
        return 0, cache

    print(f"[summaries] нужно сгенерировать: {total} (в кэше уже: {len(cache)})")
    for i, item in enumerate(todo):
        prompt = f"""Составь краткое содержание (пересказ) банковского документа на 3-6 предложений (до 1000 символов).

Название: {item['title']}

Текст:
{item['full_text'][:max_text_chars]}

Требования:
- Деловой, фактологичный стиль
- Ключевые факты: о чём документ, какие решения/проблемы, кто участвует
- Без вводных фраз типа «в данном документе», «текст описывает»
- Только суть

Пересказ:"""
        s = call_llm(prompt, max_tokens=2000)
        if s and not s.startswith('Ошибка'):
            cache[item['document_id']] = s
            generated += 1
            msg = f"  [{i+1}/{total}] {item['document_id']}: {len(s)} симв."
        else:
            cache[item['document_id']] = '[не удалось]'
            msg = f"  [{i+1}/{total}] {item['document_id']}: ОШИБКА"
        print(msg)
        if progress:
            progress(i + 1, total)
        save_cache(cache_path, cache)  # сохраняем после каждого — резюмируемость
    return generated, cache


def _norm(s):
    import re
    return re.sub(r'\s+', '', s or '').lower()
