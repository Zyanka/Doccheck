#!/usr/bin/env python3
"""
DocCheck pipeline — ЕДИНАЯ ТОЧКА ВХОДА.

Пользователь кладёт в папку реестр (XLSX) + документы в ЛЮБОМ из двух форматов:
  A) реестр + ZIP-архивы   (каждый zip — один документ)
  B) реестр + папки        (каждая папка — один документ)
Ничего дополнительно запускать не нужно — формат определяется автоматически.

Пайплайн (порядок как в document_analyzer.py):
  1) ОБНАРУЖЕНИЕ: реестр + (zip | папки)
  2) ПАРСИНГ: PDF/DOCX/XLSX; PDF без текстового слоя → OCR (EasyOCR, ru)
  3) ПЕРЕСКАЗЫ: для документов без пересказа в реестре — LLM генерирует
  4) РЕЕСТР: выгрузка enrich_registry.xlsx (обогашённый: метод парсинга,
     файлы, пересказ + источник) — пользователь видит результат предобработки
  5) АНАЛИЗЫ (LLM):
       Тип 1 — риски и гипотезы (4 категории, примеры документов)
       Тип 2 — тематический анализ (темы, авторы, динамика)
     каждый — с темой (--theme) или без
  6) ОТЧЁТ: финальный markdown (оба анализа + статистика)

Выгрузки в out_dir:
  enriched_registry.xlsx  — обогащённый реестр (результаты парсинга и предобработки)
  docs.json               — извлечённые тексты + метаданные
  summaries.json          — кэш сгенерированных пересказов
  ocr_cache.json          — кэш OCR (резюмируемость)
  analysis_risks.json / analysis_risks.md
  analysis_topics.json / analysis_topics.md
  report_final.md

Резюмируемость: все LLM-вызовы и OCR кэшируются — при kill/перезапуске
пайплайн продолжает с места остановки (кэш в out_dir, имя по хэшу папки).

Запуск:
  python3 run_pipeline.py /path/to/папка  [--out DIR] [--theme "ТЕМА"]
                               [--no-ocr] [--skip-analysis] [--max-ocr N]
"""
import os
import sys
import re
import json
import time
import hashlib
import argparse

SCRIPTS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPTS)

import ocr_utils
from extract_docs import discover, extract_all
import registry_enrich
from summaries import load_cache, save_cache, generate_summaries, is_empty_summary
from analysis import analyze_risks, analyze_topics
from logging_utils import init_logging, log_event


def main():
    ap = argparse.ArgumentParser(description='DocCheck pipeline (реестр + zip/папки)')
    ap.add_argument('input_dir', help='Папка с реестром и документами (zip или папки)')
    ap.add_argument('--out', default=None, help='Папка для выгрузок (по умолчанию <input>/_doccheck_out)')
    ap.add_argument('--theme', default=None, help='Тема анализа (опционально)')
    ap.add_argument('--no-ocr', action='store_true', help='Не использовать OCR')
    ap.add_argument('--skip-analysis', action='store_true', help='Только парсинг+реестр+пересказы')
    ap.add_argument('--include-text-in-registry', action='store_true',
                    help='Добавить в реестр колонку с извлечённым текстом')
    ap.add_argument('--ocr-cache', default=None,
                    help='Существующий OCR-кэш (json) для переиспользования распознанного')
    ap.add_argument('--summaries-cache', default=None,
                    help='Существующий кэш пересказов (json) для переиспользования')
    args = ap.parse_args()

    input_dir = os.path.abspath(args.input_dir)
    if not os.path.isdir(input_dir):
        sys.exit(f"Папка не найдена: {input_dir}")
    out_dir = os.path.abspath(args.out or os.path.join(input_dir, '_doccheck_out'))
    os.makedirs(out_dir, exist_ok=True)

    # Кэши (имя по хэшу input_dir — чтобы разные папки не мешали друг другу)
    h = hashlib.md5(input_dir.encode()).hexdigest()[:8]
    p_summaries = os.path.join(out_dir, f'summaries_{h}.json')
    p_ocr = os.path.join(out_dir, f'ocr_cache_{h}.json')
    p_risks = os.path.join(out_dir, f'analysis_risks_{h}.json')
    p_topics = os.path.join(out_dir, f'analysis_topics_{h}.json')
    p_registry = os.path.join(out_dir, 'enriched_registry.xlsx')
    p_docs = os.path.join(out_dir, 'docs.json')

    def progress(cur, total, label=''):
        print(f"  {label} {cur}/{total}")

    # ============ 1) ОБНАРУЖЕНИЕ ============
    init_logging()
    log_event("pipeline_start", {"input_dir": input_dir, "out_dir": out_dir})
    print("=" * 60)
    print(f"[1/6] ОБНАРУЖЕНИЕ: {input_dir}")
    info = discover(input_dir)
    print(f"  Формат: {info['mode']}, элементов: {len(info['items'])}")
    print(f"  Реестр: {info['registry'] or 'НЕ НАЙДЕН'}")
    log_event("discovery_done", {"mode": info['mode'], "items": len(info['items']),
                                 "registry": info['registry']})
    if info['registry'] is None:
        sys.exit("❌ Реестр XLSX (название с 'реестр') не найден в папке.")
    if info['mode'] not in ('zips', 'folders'):
        sys.exit(f"❌ Не найдено ни ZIP-архивов, ни папок с документами.")

    # ============ 2) ПАРСИНГ ============
    print("\n" + "=" * 60)
    print(f"[2/6] ПАРСИНГ ({info['mode']})")
    ocr_reader = None
    if not args.no_ocr:
        dev, free = ocr_utils.pick_device()
        if dev == 'cpu':
            ocr_utils.force_cpu()
        print(f"  OCR: {dev} (свободно {free} МБ)")
        ocr_reader = ocr_utils.get_ocr_reader(use_gpu=(dev == 'gpu'))
        if ocr_reader is None:
            print("  OCR недоступен — PDF без текстового слоя будут пропущены")
    ocr_cache = load_cache(p_ocr)
    # Переиспользование существующего OCR-кэша (например, от предыдущего прогона)
    if args.ocr_cache and os.path.exists(args.ocr_cache):
        seed = load_cache(args.ocr_cache)
        added = 0
        for k, v in seed.items():
            if k not in ocr_cache:
                ocr_cache[k] = v
                added += 1
        print(f"  OCR-кэш: подгружено {added} файлов из {args.ocr_cache}")
    t0 = time.time()
    docs, parse_log = extract_all(input_dir, ocr_reader, ocr_cache, p_ocr)
    from collections import Counter
    mc = Counter(d['method'].split(' ')[0] for d in docs)
    print(f"  Извлечено {len(docs)} документов за {time.time()-t0:.0f}с, методы: {dict(mc)}")
    log_event("parsing_done", {"total_docs": len(docs), "methods": dict(mc),
                                "elapsed_sec": round(time.time()-t0)})

    # ============ 3) ПЕРЕСКАЗЫ ============
    print("\n" + "=" * 60)
    print("[3/6] ПЕРЕСКАЗЫ (для документов без пересказа в реестре)")
    header, reg = registry_enrich.read_registry(info['registry'])
    print(f"  Записей в реестре: {len(reg)}")

    # полный текст по document_id: ключи — нормализованный id и номерный
    # (папки «исх_19», реестр «исх/19» → общий ключ __num_19)
    full_by_id = {}
    for d in docs:
        keys = {re.sub(r'\s+', '', d['doc_id']).lower()}
        m = re.search(r'исх[/_](\d+)', d['doc_id'].lower())
        if m:
            keys.add(f"__num_{m.group(1)}")
        for k in keys:
            full_by_id[k] = (full_by_id.get(k, '') + '\n\n' + d['text'])[:20000]

    summaries = load_cache(p_summaries)
    # Переиспользование существующего кэша пересказов
    if args.summaries_cache and os.path.exists(args.summaries_cache):
        seed_s = load_cache(args.summaries_cache)
        added_s = 0
        for k, v in seed_s.items():
            if k not in summaries:
                summaries[k] = v
                added_s += 1
        print(f"  Пересказы: подгружено {added_s} из {args.summaries_cache}")
    n_gen, summaries = generate_summaries(reg, full_by_id, summaries, p_summaries,
                                          progress=progress)
    print(f"  Сгенерировано новых пересказов: {n_gen}, всего в кэше: {len(summaries)}")
    log_event("summaries_done", {"generated": n_gen, "total_cached": len(summaries),
                                 "registry_entries": len(reg)})

    # ============ 4) РЕЕСТР (обогашённый) ============
    print("\n" + "=" * 60)
    print("[4/6] ВЫГРУЗКА ОБОГАЩЁННОГО РЕЕСТРА")
    enriched = registry_enrich.enrich_registry(
        header, reg, docs, summaries, p_registry,
        include_full_text=args.include_text_in_registry)
    n_src = Counter(row['Источник пересказа'] for row in enriched)
    print(f"  {p_registry}")
    print(f"  Источники пересказов: {dict(n_src)}")
    log_event("registry_enriched", {"rows": len(enriched), "sources": dict(n_src)})

    # сохраняем docs.json
    json.dump({'docs': docs, 'registry': reg, 'parse_log': parse_log,
               'summaries': summaries, 'mode': info['mode']},
              open(p_docs, 'w', encoding='utf-8'), ensure_ascii=False)
    print(f"  {p_docs}")

    if args.skip_analysis:
        print("\n[skip-analysis] Завершено на этапе реестра.")
        return

    # ============ 5) АНАЛИЗЫ ============
    print("\n" + "=" * 60)
    print(f"[5/6] LLM-АНАЛИЗЫ" + (f" (тема: {args.theme})" if args.theme else " (без темы)"))
    reg_by_id = {}
    for r in reg:
        did = r.get('document_id', '')
        if not did:
            continue
        norm = re.sub(r'\s+', '', did).lower()
        reg_by_id[norm] = r
        m = re.search(r'исх[/_](\d+)', did.lower())
        if m:
            reg_by_id[f"__num_{m.group(1)}"] = r

    print("\n  --- Тип 1: Анализ рисков и гипотез ---")
    risks_cache = load_cache(p_risks)
    agg, risks_md = analyze_risks(docs, reg_by_id, summaries, theme=args.theme,
                                  cache=risks_cache, cache_path=p_risks, progress=progress)
    json.dump(agg, open(os.path.join(out_dir, 'analysis_risks.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)
    open(os.path.join(out_dir, 'analysis_risks.md'), 'w', encoding='utf-8').write(risks_md)
    print(f"  рисков: опер={len(agg['risks']['operational'])}, процесс={len(agg['risks']['process'])}, "
          f"кадров={len(agg['risks']['personnel'])}, фрод={len(agg['risks']['fraud_indicators'])}")
    log_event("analysis_risks_done", {
        "operational": len(agg['risks']['operational']),
        "process": len(agg['risks']['process']),
        "personnel": len(agg['risks']['personnel']),
        "fraud": len(agg['risks']['fraud_indicators']),
        "theme": args.theme
    })

    print("\n  --- Тип 2: Общий тематический анализ ---")
    topics_cache = load_cache(p_topics)
    topics, topics_md = analyze_topics(docs, reg_by_id, summaries, theme=args.theme,
                                       cache=topics_cache, cache_path=p_topics, progress=progress)
    json.dump({'topics': topics['topics'], 'authors': topics['authors'],
               'monthly': topics['monthly'], 'urgent_trends': topics['urgent_trends'],
               'recommendations': topics['recommendations'], 'total': topics['total'],
               'chunks': topics['chunks'], 'theme': args.theme},
              open(os.path.join(out_dir, 'analysis_topics.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)
    open(os.path.join(out_dir, 'analysis_topics.md'), 'w', encoding='utf-8').write(topics_md)
    print(f"  тем: {len(topics['topics'])}, авторов: {len(topics['authors'])}")
    log_event("analysis_topics_done", {
        "topics": len(topics['topics']),
        "authors": len(topics['authors']),
        "theme": args.theme
    })

    # ============ 6) ОТЧЁТ ============
    print("\n" + "=" * 60)
    print("[6/6] ФИНАЛЬНЫЙ ОТЧЁТ")
    report = _final_report(args, info, docs, enriched, agg, topics, out_dir)
    p_report = os.path.join(out_dir, 'report_final.md')
    open(p_report, 'w', encoding='utf-8').write(report)
    print(f"  {p_report}")
    print("\n✅ ГОТОВО. Ключевые выгрузки:")
    for p in [p_registry, p_report,
              os.path.join(out_dir, 'analysis_risks.md'),
              os.path.join(out_dir, 'analysis_topics.md')]:
        print(f"  - {p}")
    log_event("pipeline_done", {"input_dir": input_dir, "out_dir": out_dir})


def _final_report(args, info, docs, enriched, agg, topics, out_dir):
    from collections import Counter
    theme = f" по теме «{args.theme}»" if args.theme else ''
    mc = Counter(d['method'].split(' ')[0] for d in docs)
    src = Counter(row['Источник пересказа'] for row in enriched)
    n_ocr = sum(1 for d in docs if d['method'].startswith('ocr'))
    lines = [
        f"# Отчёт DocCheck — анализ документов{theme}\n",
        f"**Папка с документами:** {args.input_dir}\n",
        f"**Формат входных данных:** реестр + {'ZIP-архивы' if info['mode']=='zips' else 'папки'} (определено автоматически)\n",
        f"**Документов извлечено:** {len(docs)} | **Записей в реестре:** {len(enriched)}\n",
        f"**Методы парсинга:** {dict(mc)} (OCR: {n_ocr} файлов)\n",
        f"**Источники пересказов:** {dict(src)}\n",
        "\n---\n",
        "## Анализ 1. Риски и гипотезы\n",
        "",
    ]
    risks_md = open(os.path.join(out_dir, 'analysis_risks.md'), encoding='utf-8').read()
    # снимаем заголовок h1, чтобы не дублировался
    risks_md = re.sub(r'^# .*?\n', '', risks_md, count=1)
    lines.append(risks_md)
    lines.append("\n---\n")
    lines.append("## Анализ 2. Общий тематический анализ\n\n")
    topics_md = open(os.path.join(out_dir, 'analysis_topics.md'), encoding='utf-8').read()
    topics_md = re.sub(r'^# .*?\n', '', topics_md, count=1)
    lines.append(topics_md)
    return '\n'.join(lines)


if __name__ == '__main__':
    main()
