"""
Извлечение текста из документов (PDF/DOCX/XLSX) + обнаружение входного формата.

Поддерживает два варианта входных данных пользователя:
  A) реестр (XLSX) + ZIP-архивы (каждый zip — один документ)
  B) реестр (XLSX) + папки (каждая папка — один документ)

Скрипт сам определяет вариант и работает без дополнительных параметров.
PDF без текстового слоя (менее 10 символов) → OCR, если доступен.

Возвращает список docs: {doc_id, folder, file, date, type, text, chars, method}
и parse_log: {folder, file, method, chars}.
"""
import os
import re
import io
import json
import zipfile
import tempfile
import shutil
import time

TEXT_THRESHOLD = 10  # символов: меньше — считаем, что нет текстового слоя

def _clean_id(s):
    return re.sub(r'\s+', '', s or '')


def _doc_id_from_zip(name):
    """doc_id из имени zip: 'Письмо ЦА-662-исх_10 от 02.02.2026.zip' -> 'ЦА-662-исх_10'"""
    base = os.path.basename(name)
    base = re.sub(r'\.zip$', '', base, flags=re.I)
    m = re.search(r'(ЦА[^\s]+?\s?исх[/_]\d+)', base)
    return _clean_id(m.group(1)) if m else _clean_id(base)


def _doc_id_from_folder(name):
    base = os.path.basename(name)
    m = re.search(r'(ЦА[^\s]+?\s?исх[/_]\d+)', base)
    return _clean_id(m.group(1)) if m else _clean_id(base)


def _date_from_name(name):
    m = re.search(r'от\s*(\d{2})\.(\d{2})\.(\d{4})', name)
    return f"{m.group(3)}-{m.group(2)}-{m.group(1)}" if m else ''


def extract_file(fpath, fname, ocr_reader=None):
    """
    Возвращает (text, method).
    method: text | needs_ocr | xlsx | empty | error | skip
    'needs_ocr' — PDF без текстового слоя; вызывающий резолвит OCR с кэшем (resolve_ocr).
    """
    ext = os.path.splitext(fname)[1].lower()
    if ext == '.pdf':
        try:
            import fitz
            doc = fitz.open(fpath)
            text = ''.join(doc.load_page(i).get_text() for i in range(len(doc)))
            doc.close()
            if len(text.strip()) >= TEXT_THRESHOLD:
                return text.strip(), 'text'
            # Нет текстового слоя → нужно OCR (резолвится снаружи, с кэшем)
            return '', 'needs_ocr'
        except Exception as e:
            return f'[Ошибка PDF: {e}]', 'error'
    elif ext == '.docx':
        try:
            import docx
            d = docx.Document(fpath)
            parts = [p.text for p in d.paragraphs if p.text.strip()]
            for tb in d.tables:
                for row in tb.rows:
                    cells = [c.text.strip() for c in row.cells if c.text.strip()]
                    if cells:
                        parts.append(' | '.join(cells))
            text = '\n'.join(parts)
            return (text.strip(), 'text') if text.strip() else ('', 'empty')
        except Exception as e:
            return f'[Ошибка DOCX: {e}]', 'error'
    elif ext in ('.xlsx', '.xls', '.xlsm'):
        try:
            import openpyxl
            wb = openpyxl.load_workbook(fpath, read_only=True, data_only=True)
            lines = []
            for ws in wb.worksheets:
                for i, row in enumerate(ws.iter_rows(values_only=True, max_row=500)):
                    if i >= 500:
                        break
                    cells = [str(c).strip() for c in row if c is not None and str(c).strip()]
                    if cells:
                        lines.append(' | '.join(cells))
            wb.close()
            text = '\n'.join(lines).strip()
            return (text, 'xlsx') if text else ('', 'empty')
        except Exception as e:
            return f'[Ошибка XLSX: {e}]', 'error'
    else:
        return '', 'skip'


def resolve_ocr(fpath, fname, ocr_reader, ocr_cache, ocr_cache_path, cache_key=None):
    """
    Резолвит 'needs_ocr': берёт из кэша или распознаёт и сохраняет в кэш.
    Возвращает (text, method). method: ocr (NNс) | ocr_cached | empty
    cache_key: ключ кэша (по умолчанию abspath(fpath)).
    """
    from ocr_utils import ocr_pdf, save_cache
    if cache_key is None:
        cache_key = os.path.abspath(fpath)
    if ocr_cache and cache_key in ocr_cache:
        return ocr_cache[cache_key].get('text', ''), 'ocr_cached'
    if ocr_reader is None:
        return '', 'empty (без OCR)'
    t0 = time.time()
    t = ocr_pdf(fpath, ocr_reader)
    dt = time.time() - t0
    if ocr_cache is not None and ocr_cache_path:
        ocr_cache[cache_key] = {'text': t, 'chars': len(t),
                                'ts': time.strftime('%Y-%m-%d %H:%M:%S')}
        save_cache(ocr_cache_path, ocr_cache)
    if t.strip():
        return t, f'ocr ({dt:.0f}с)'
    return '', 'empty'


def discover(input_dir):
    """
    Определяет входной формат:
      {'mode': 'folders', 'registry': path|None, 'items': [(name, path), ...]}
      {'mode': 'zips',    'registry': path|None, 'items': [(name, path), ...]}
    """
    names = [n for n in os.listdir(input_dir) if not n.startswith('.')]
    registry = None
    for n in names:
        if n.lower().endswith(('.xlsx', '.xls')) and re.search(r'реестр|registry', n, re.I):
            registry = os.path.join(input_dir, n)
            break
    zips = [os.path.join(input_dir, n) for n in names if n.lower().endswith('.zip')]
    folders = [os.path.join(input_dir, n) for n in names
               if os.path.isdir(os.path.join(input_dir, n)) and not n.startswith('.')]
    # Если zip'ы внутри архива-папки — ищем рекурсивно на уровень
    if not zips and not folders:
        for n in names:
            p = os.path.join(input_dir, n)
            if os.path.isdir(p):
                zips += [os.path.join(p, f) for f in os.listdir(p) if f.lower().endswith('.zip')]
                folders += [os.path.join(p, f) for f in os.listdir(p)
                            if os.path.isdir(os.path.join(p, f))]
    if zips:
        return {'mode': 'zips', 'registry': registry, 'items': sorted(zips)}
    if folders:
        return {'mode': 'folders', 'registry': registry, 'items': sorted(folders)}
    return {'mode': None, 'registry': registry, 'items': []}


def extract_all(input_dir, ocr_reader=None, ocr_cache=None, ocr_cache_path=None):
    """
    Парсит все документы (zip или папки). Возвращает (docs, parse_log).
    ocr_cache: dict {path: {text, ...}} — кэш OCR (по пути файла), сохраняется по ходу.
    """
    info = discover(input_dir)
    if info['mode'] == 'zips':
        return _extract_zips(info['items'], ocr_reader, ocr_cache, ocr_cache_path)
    if info['mode'] == 'folders':
        return _extract_folders(info['items'], ocr_reader, ocr_cache, ocr_cache_path)
    raise ValueError(f"Не найдено ни ZIP-архивов, ни папок с документами в {input_dir}")


def _extract_zips(items, ocr_reader, ocr_cache, ocr_cache_path):
    docs, parse_log = [], []
    for zip_path in items:
        doc_id = _doc_id_from_zip(zip_path)
        date = _date_from_name(zip_path)
        tmpdir = tempfile.mkdtemp(prefix='dc_')
        try:
            with zipfile.ZipFile(zip_path) as zf:
                zf.extractall(tmpdir)
            for root, _, files in os.walk(tmpdir):
                for fn in sorted(files):
                    if fn.startswith('.') or fn.lower().endswith('.ppdf'):
                        continue
                    fp = os.path.join(root, fn)
                    # Кэш OCR: ключ = zip + файл + размер (содержимое стабильно)
                    cache_key = 'zip::' + os.path.basename(zip_path) + '::' + fn + '::' + str(os.path.getsize(fp))
                    text, method = extract_file(fp, fn, ocr_reader)
                    if method == 'needs_ocr':
                        text, method = resolve_ocr(fp, fn, ocr_reader, ocr_cache, ocr_cache_path, cache_key)
                    if text and not text.startswith('[Ошибка'):
                        docs.append({'doc_id': doc_id, 'folder': os.path.basename(zip_path),
                                     'file': fn, 'date': date,
                                     'type': os.path.splitext(fn)[1].lower().lstrip('.'),
                                     'text': text, 'chars': len(text), 'method': method})
                    parse_log.append({'folder': os.path.basename(zip_path), 'file': fn,
                                      'method': method, 'chars': len(text)})
                    if method.startswith('ocr') and method != 'ocr_cached':
                        print(f"  OCR: {os.path.basename(zip_path)}/{fn} → {method}, {len(text)} симв.")
        except Exception as e:
            parse_log.append({'folder': os.path.basename(zip_path), 'file': '',
                              'method': f'error: {e}', 'chars': 0})
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)
    return docs, parse_log


def _extract_folders(items, ocr_reader, ocr_cache, ocr_cache_path):
    docs, parse_log = [], []
    for folder in items:
        fname = os.path.basename(folder)
        date = _date_from_name(fname)
        doc_id = _doc_id_from_folder(fname)
        try:
            files = [f for f in sorted(os.listdir(folder))
                     if not f.startswith('.') and not os.path.isdir(os.path.join(folder, f))]
        except Exception:
            continue
        for fn in files:
            if fn.lower().endswith('.ppdf'):
                continue
            fp = os.path.join(folder, fn)
            # Кэш OCR по абсоютному пути файла
            cache_key = os.path.abspath(fp)
            text, method = extract_file(fp, fn, ocr_reader)
            if method == 'needs_ocr':
                text, method = resolve_ocr(fp, fn, ocr_reader, ocr_cache, ocr_cache_path, cache_key)
            if text and not text.startswith('[Ошибка'):
                docs.append({'doc_id': doc_id, 'folder': fname, 'file': fn,
                             'date': date, 'type': os.path.splitext(fn)[1].lower().lstrip('.'),
                             'text': text, 'chars': len(text), 'method': method})
            parse_log.append({'folder': fname, 'file': fn, 'method': method, 'chars': len(text)})
            if method.startswith('ocr') and method != 'ocr_cached':
                print(f"  OCR: {fname}/{fn} → {method}, {len(text)} симв.")
    return docs, parse_log
