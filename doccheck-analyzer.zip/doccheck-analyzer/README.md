# DocCheck Analyzer

Самодостаточный пайплайн анализа внутренней документации банка для внутреннего аудита.

## Быстрый старт

```bash
# 1. Установить зависимости
pip install -r scripts/requirements.txt

# 2. (Опционально) Установить модели OCR
mkdir -p ~/.EasyOCR/model
# Распаковать cyrillic_g2.pth и craft_mlt_25k.pth в ~/.EasyOCR/model/

# 3. Запустить
export JPY_API_TOKEN=***
export GC_API_URL=http://liveaccess/v1/gc
python3 scripts/run_pipeline.py /path/to/папка_с_реестром_и_документами
```

## Структура

```
doccheck-analyzer/
├── SKILL.md                  # Спецификация скилла (полная документация)
├── README.md                  # Этот файл
├── scripts/
│   ├── run_pipeline.py        # Единая точка входа
│   ├── ocr_utils.py           # OCR: автовыбор GPU/CPU, кэш
│   ├── extract_docs.py        # Парсинг PDF/DOCX/XLSX + автоопределение zip/папки
│   ├── summaries.py           # LLM-пересказы + кэш
│   ├── registry_enrich.py     # Обогащение реестра в XLSX
│   ├── analysis.py            # Два типа LLM-анализа (риски, тематика)
│   ├── logging_utils.py       # Логирование (JSONL) + выгрузка в HDFS
│   └── requirements.txt       # Зависимости
└── references/
    ├── analyze-cb-docs.md      # Методология анализа документов ЦБ
    └── cb-docs-analysis.md    # Детальный разбор кейсов
```

## Установка как скилл Hermes Agent

```bash
cp -r doccheck-analyzer ~/.hermes_local/skills/data/
```

После установки скилл доступен в Hermes: `skill_view(name='doccheck-analyzer')`

## Возможности

- Автоопределение формата (ZIP-архивы или папки)
- Парсинг PDF (включая OCR), DOCX, XLSX
- LLM-пересказы для документов без аннотации
- Обогащённый реестр с методами парсинга и пересказами
- Анализ рисков (4 категории: операционные, процессные, кадровые, фрод)
- Тематический анализ (темы, авторы, динамика по месяцам)
- Резюмируемость: кэши на диск, прерывание и возобновление
- Логирование в JSONL + выгрузка в HDFS (совместимо со Streamlit-версией)

## Версия

2.0.0 (MIT License)